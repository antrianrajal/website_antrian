<style>
    body {
        overflow: hidden;
        font-family: Arial, Helvetica, sans-serif;
    }

    .card-blur {
        background-color: #fdfeff47;
        -webkit-backdrop-filter: blur(5px);
        backdrop-filter: blur(5px);
        border-radius: 10px;
    }

    .row {
        margin: 0px;
    }

    .card {
        border-radius: 0.2rem;
    }

    .card-header {
        background-color: rgba(0, 0, 0, .0) !important;
    }

    .card-footer {
        background-color: rgba(0, 0, 0, .0) !important;
    }

    h5.nama-instansi {
        margin-bottom: 0.1rem;
    }
</style>