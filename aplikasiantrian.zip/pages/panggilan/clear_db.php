<?php

// panggil file "database.php" untuk koneksi ke database
require_once "../../config/query.php";

// sql statement untuk menampilkan jumlah data dari tabel "tbl_antrian" berdasarkan "tanggal"
$query = mysqli_query($mysqli, "TRUNCATE TABLE queue_antrian_admisi")
    or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));

// redirect();
header("location:" . $base_url);
