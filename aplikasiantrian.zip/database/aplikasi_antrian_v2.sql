-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 02 Apr 2024 pada 10.49
-- Versi server: 8.0.30
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aplikasi_antrian_v2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `queue_antrian_admisi`
--

CREATE TABLE `queue_antrian_admisi` (
  `id` bigint NOT NULL,
  `tanggal` date NOT NULL,
  `no_antrian` varchar(3) NOT NULL,
  `code_antrian` char(5) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Struktur dari tabel `queue_setting`
--

CREATE TABLE `queue_setting` (
  `id` int NOT NULL,
  `nama_instansi` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telpon` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `running_text` varchar(255) DEFAULT NULL,
  `youtube_id` varchar(255) DEFAULT NULL,
  `list_loket` longtext,
  `list_type_antrian` longtext,
  `warna_primary` varchar(255) DEFAULT NULL,
  `warna_secondary` varchar(255) DEFAULT NULL,
  `warna_accent` varchar(255) DEFAULT NULL,
  `warna_background` varchar(255) DEFAULT NULL,
  `warna_text` varchar(255) DEFAULT NULL,
  `printer` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `queue_setting`
--

INSERT INTO `queue_setting` (`id`, `nama_instansi`, `logo`, `alamat`, `telpon`, `email`, `running_text`, `youtube_id`, `list_loket`, `list_type_antrian`, `warna_primary`, `warna_secondary`, `warna_accent`, `warna_background`, `warna_text`, `printer`) VALUES
(1, 'PUSKESMAS NAGREG', 'logo.png', 'Jl. Raya Nagreg KM.37, Nagreg, Kec. Nagreg, Kabupaten Bandung, Jawa Barat 40215', '083829722349', 'puskesmasnagreg@gmail.com', 'SELAMAT DATANG DI PUSKESMAS NAGREG, KAB. BANDUNG JAWA BARAT', 'C1d35JcifZg', '[{\"no_loket\":\"1\",\"nama_loket\":\"Loket 1\",\"handle_type_antrian\":\"[\\\"U\\\"]\"},{\"no_loket\":\"2\",\"nama_loket\":\"Loket 2\",\"handle_type_antrian\":\"[\\\"B\\\"]\"},{\"no_loket\":\"3\",\"nama_loket\":\"Loket 3\",\"handle_type_antrian\":\"[\\\"P\\\"]\"}]', '[{\"type_antrian\":\"UMUM\",\"code_antrian\":\"U\"},{\"type_antrian\":\"BPJS\",\"code_antrian\":\"B\"},{\"type_antrian\":\"PRIORITAS\",\"code_antrian\":\"P\"}]', '#3cb470', '#de8c8c', '#88b1dd', '#76e5a6', '#ffffff', '{\"ip_komputer_printer\":\"127.0.0.1\",\"nama_sharing_printer\":\"pos-58\",\"tipe_font_no_antrian\":\"FONT_A\",\"lebar_font_no_antrian\":\"1\",\"tinggi_font_no_antrian\":\"1\",\"header_struk\":\"PUSKESMAS NAGREG newLine\",\"tipe_font_header\":\"FONT_A\",\"lebar_font_header\":\"1\",\"tinggi_font_header\":\"1\",\"alamat_struk\":\"Jl. Raya Nagreg KM.37, Nagreg, Kec. Nagreg, Kabupaten Bandung, Jawa Barat 40215 newLine\",\"tipe_font_alamat\":\"FONT_B\",\"lebar_font_alamat\":\"1\",\"tinggi_font_alamat\":\"1\",\"informasi_struk\":\"Silahkan menunggu nomor antrian dipanggil newLine Nomor ini hanya berlaku pada hari dicetak newLine\",\"tipe_font_informasi\":\"FONT_A\",\"lebar_font_informasi\":\"1\",\"tinggi_font_informasi\":\"1\",\"footer_struk\":\"TERIMA KASIH, ANDA TELAH TERTIB\",\"tipe_font_footer\":\"FONT_A\",\"lebar_font_footer\":\"1\",\"tinggi_font_footer\":\"1\"}');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `queue_antrian_admisi`
--
ALTER TABLE `queue_antrian_admisi`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `Fk_queue_antrian_admisi_type` (`code_antrian`);

--
-- Indeks untuk tabel `queue_setting`
--
ALTER TABLE `queue_setting`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `queue_antrian_admisi`
--
ALTER TABLE `queue_antrian_admisi`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `queue_setting`
--
ALTER TABLE `queue_setting`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
